const { ethers } = require("ethers");
const Launchpad = require("../abi/Launchpad.json");

const LaunchpadAbi = Launchpad.abi;
const LaunchpadAddress = "0xCf7Ed3AccA5a467e9e704C703E8D87F634fB0Fc9";
const apiURL =
  "https://polygon-mainnet.g.alchemy.com/v2/hchNXfJU-FCzljA7vy1GoF7CqRKgzoDW";
const apiURL2 = "http://127.0.0.1:8545";

let  backendCallApiHost = 'https://api.dev.hackquest.io/v1';

var init = function () {
  const provider = new ethers.providers.JsonRpcProvider(apiURL2);
  const contract = new ethers.Contract(
    LaunchpadAddress,
    LaunchpadAbi,
    provider
  );
  const AddLaunchpadEvent = "AddLaunchpad";
  const ClaimEvent = "Claimed";
  const StakeEvent = "Staked";
  const UnStakeEvent = "UnStaked";
  contract.on(AddLaunchpadEvent, (launchpadId, launchedAddress, chainID, event) => {
    console.log(
      `AddLaunchpad event triggered - launchpadId: ${launchpadId}, launchedAddress: ${launchedAddress}, chainID: ${chainID}`);
    console.log("Event details:", event);

    try {//
      let notifyUrl = backendCallApiHost + `/event/addLaunchpad?launchpadId=${launchpadId}&chainID=${chainID}`;
      console.log(' Convert  Event  notifyUrl ', notifyUrl);
      fetch(notifyUrl, {
        headers: {
          'Accept-Language': 'zh-CN' // Replace with your desired language code
        }
      })
        .then(response => response.json())
        .then(data => {
          console.log("接口响应数据：", data);
        })
        .catch(error => {
          console.error("发生错误：", error);
        });
    } catch (error) {
      console.error("发生错误：", error);
    }


  });

  contract.on(
    ClaimEvent,
    (userAddress, launchpadId, points, token, amount, timestamp, chainID, event) => {
      console.log(
        `Claimed event triggered - userAddress: ${userAddress}, launchpadId: ${launchpadId}, points: ${points}, token: ${token}, amount: ${amount}, timestamp: ${timestamp}, chainID: ${chainID}`
      );
      console.log("Event details:", event);

      // try {//
      //   let notifyUrl = backendCallApiHost + `/event/addLaunchpad?launchpadId=${launchpadId}&chainID=${chainID}`;
      //   console.log(' Convert  Event  notifyUrl ', notifyUrl);
      //   fetch(notifyUrl, {
      //     headers: {
      //       'Accept-Language': 'zh-CN' // Replace with your desired language code
      //     }
      //   })
      //     .then(response => response.json())
      //     .then(data => {
      //       console.log("接口响应数据：", data);
      //     })
      //     .catch(error => {
      //       console.error("发生错误：", error);
      //     });
      // } catch (error) {
      //   console.error("发生错误：", error);
      // }


    }
  );
  contract.on(
    StakeEvent,
    (userAddress, launchpadId, index, token, amount, timestamp, chainID, event) => {
      console.log(
        `Staked event triggered - userAddress: ${userAddress}, launchpadId: ${launchpadId}, index: ${index}, token: ${token}, amount: ${amount}, timestamp: ${timestamp}, chainID: ${chainID}`
      );
      console.log("Event details:", event);


      try {//
        let notifyUrl = backendCallApiHost + `/event/staked?launchpadId=${launchpadId}&chainID=${chainID}&user=${userAddress}&index=${index}&amount=${amount}&timestamp=${timestamp}&token=${token}`;
        console.log(' Convert  Event  notifyUrl ', notifyUrl);
        fetch(notifyUrl, {
          headers: {
            'Accept-Language': 'zh-CN' // Replace with your desired language code
          }
        })
          .then(response => response.json())
          .then(data => {
            console.log("接口响应数据：", data);
          })
          .catch(error => {
            console.error("发生错误：", error);
          });
      } catch (error) {
        console.error("发生错误：", error);
      }



    }
  );
  contract.on(
    UnStakeEvent,
    (userAddress, launchpadId, index, token, amount, timestamp, chainID, event) => {
      console.log(
        `UnStaked event triggered - userAddress: ${userAddress}, launchpadId: ${launchpadId}, index: ${index}, token: ${token}, amount: ${amount}, timestamp: ${timestamp}, chainID: ${chainID}`
      );
      console.log("Event details:", event);

      try {//
        let notifyUrl = backendCallApiHost + `/event/unstaked?launchpadId=${launchpadId}&chainID=${chainID}&user=${userAddress}&amount=${amount}&timestamp=${timestamp}&token=${token}`;
        console.log(' Convert  Event  notifyUrl ', notifyUrl);
        fetch(notifyUrl, {
          headers: {
            'Accept-Language': 'zh-CN' // Replace with your desired language code
          }
        })
          .then(response => response.json())
          .then(data => {
            console.log("接口响应数据：", data);
          })
          .catch(error => {
            console.error("发生错误：", error);
          });
      } catch (error) {
        console.error("发生错误：", error);
      }


    }
  );
};

init();
