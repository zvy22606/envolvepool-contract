const { ethers } = require("ethers");


// 连接到以太坊节点
const provider = new ethers.providers.JsonRpcProvider("http://127.0.0.1:8545");

// 使用私钥连接到账户
const privateKey = "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80";
const wallet = new ethers.Wallet(privateKey, provider);

// 读取 ABI 文件
const launchapToken1abi = require("../abi/LaunchapToken.json");
const stakingTokenabi = require("../abi/StakingToken.json");
const launchpadabi = require("../abi/Launchpad.json");
const launchapToken1Abi = launchapToken1abi.abi;
const stakingTokenAbi = stakingTokenabi.abi;
const launchpadAbi = launchpadabi.abi;
// 获取已部署的合约实例
const launchapToken1Address = "0x5FbDB2315678afecb367f032d93F642f64180aa3";
const stakingTokenAddress = "0x9fE46736679d2D9a65F0992F2272dE9f3c7fa6e0";
const launchpadAddress = "0xCf7Ed3AccA5a467e9e704C703E8D87F634fB0Fc9";

const launchapToken1 = new ethers.Contract(launchapToken1Address, launchapToken1Abi, wallet);
const stakingToken = new ethers.Contract(stakingTokenAddress, stakingTokenAbi, wallet);
const launchpad = new ethers.Contract(launchpadAddress, launchpadAbi, wallet);

// 执行操作
const owner = wallet.address;



async function executeLaunchpadOperations() {
    await launchapToken1.mint(
        owner,
        ethers.utils.parseUnits("10000", 18)
    );
    await stakingToken.mint(
        owner,
        ethers.utils.parseUnits("10000", 18)
    );
    await stakingToken.approve(
        launchpad.address,
        ethers.utils.parseUnits("10000", 18)
    );

    console.log("Tokens minted and approved successfully!");
    const _name = "MyStakingPool";
    const _startTime = Math.floor(Date.now() / 1000);
    const _endTime = _startTime + 3600;
    const _LowStakingTime = 3600;
    const _LowStakingAmount = ethers.utils.parseUnits("10", 18);
    const _exchangeCharge = 0;

    // 添加 Launchpad
    await launchpad.addLaunchpad(
        _name,
        stakingTokenAddress,
        launchapToken1Address,
        _startTime,
        _endTime,
        _LowStakingTime,
        _exchangeCharge,
        _LowStakingAmount,
        launchpadAddress,
        launchapToken1Address
    );

    // 获取 Launchpad 信息
    const launchpadInfo = await launchpad.launchpads(0);
    console.log("Launchpad Info:", launchpadInfo);

    // 验证用户检查点
    await launchpad.UserChecks(0, wallet.address, 1).then(console.log);

    // 显示检查点
    await launchpad.trackCheckpoints(0).then(console.log);

    // 质押
    await launchpad.stake(0, ethers.utils.parseUnits("10", 18));

    // 再次验证用户检查点
    await launchpad.UserChecks(0, wallet.address, 1).then(console.log);

    // 显示更新后的检查点
    await launchpad.trackCheckpoints(0).then(console.log);

    // 取回质押
    await launchpad.unstake(0, 1).then(console.log);

    // 最终用户检查点
    await launchpad.UserChecks(0, wallet.address, 0).then(console.log);

    // 最终检查点
    await launchpad.trackCheckpoints(0).then(console.log);
}

executeLaunchpadOperations()
